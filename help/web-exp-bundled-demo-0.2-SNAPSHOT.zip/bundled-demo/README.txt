
THIS is a pre-configured DEMO of the Web Experiments Web-Application and comes to you WITHOUT ANY WARRANTY.

Source Code:
https://github.com/mukil/web-experiments

Help:
https://github.com/mukil/web-experiments/blob/master/docs/content/index.md


### Vital: Must set the filerepo path first

Set `dm4.filerepo.path` in `deepamehta-4.4.3/conf/config.properties` to the dm4-filerepo folder in this directory.

### Start the platform

In a terminal on Ubuntu:
<pre>
cd deepamehta-4.4.3
./deepamehta-linux.sh
</pre>

Open http://localhost:8080/web-exp/ in your web-browser.


